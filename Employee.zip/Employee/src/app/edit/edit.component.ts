import { Component, OnInit } from '@angular/core';
import { Employee } from '../models/employee.model';
import { EmpserviceService } from '../services/empservice.service';
import { Router, ActivatedRoute } from '@angular/router';
import {filter} from 'rxjs/operators';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  emp: Employee;

  constructor(private service: EmpserviceService,
    private router: Router,
    private routes:ActivatedRoute) { 
    this.emp = new Employee();
  }

  ngOnInit() {
    if (window.location.search !== '') {
      this.routes.queryParams.pipe(
      filter(params => params.index)) //find the index
      .subscribe(params => {
      var paramIndex = params.index; //save the index
      this.emp = this.service.getByIdx(paramIndex); //fetch data from that index
    });
  }
}

  updateEmp()
  {
    // angular updates the values in array automatically as we change the data 
    this.router.navigate(['list']) //navigate to todo
  }
}
