import { Component, OnInit } from '@angular/core';
import { EmpserviceService } from '../services/empservice.service';
import { Employee } from '../models/employee.model';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  empno : number;
  emp : Employee;
  submitted : boolean;

  constructor(private service : EmpserviceService) { }

  ngOnInit() {
  }

  searchEmp() {
    this.emp = this.service.searchByNo(this.empno);
    if(this.emp != null)
      this.submitted = true;
  }
}
