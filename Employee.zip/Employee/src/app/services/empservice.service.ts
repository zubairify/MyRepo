import { Injectable, OnInit } from '@angular/core';
import { Employee } from '../models/employee.model';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class EmpserviceService {
  emps : Employee[] = [];

  // Http client injection
  constructor(private http : HttpClient, private routes: Router) {
    this.http.get<Employee[]>('../assets/emps.json').subscribe(data => this.emps = data);
    console.log(this.emps);
  }

  // Add employee into array
  addEmp(e : Employee) {
    this.emps.push(e);
    console.log(JSON.stringify(this.emps));
  }

  // Return arrays of employees
  fetchAll() : Employee[] {
    return this.emps;
  }

  editEmp(index: number) {
    this.routes.navigate(['edit'], { queryParams: { index: index } });
  }

  // Delete an employee
  deleteEmp(index: number) {
    return this.emps.splice(index, 1);
  }

  // Sort employees by salary
  sortEmpBySalary() {
    this.emps.sort((a, b) => a.salary > b.salary ? 1 : (
                (a.salary < b.salary) ? -1 : 0));
    return this.emps;
  }

  // Sort employees by name
  sortEmpByName() {
    this.emps.sort((a, b) => a.empname > b.empname ? 1 : (
                (a.empname < b.empname) ? -1 : 0));
    return this.emps;
  }

  // Search employee by no
  searchByNo(eno : number) {
    return this.emps.find(x => x.empno == eno);
  }

  getByIdx(index: number) {
    return this.emps[index];
  }

}
