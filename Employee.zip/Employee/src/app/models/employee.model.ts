
export class Employee {
    empno : number;
    empname : string;
    salary : number;
    mobile : string;
    email : string;
}
