import { Component, OnInit, Input } from '@angular/core';
import { EmpserviceService } from '../services/empservice.service';
import { Employee } from '../models/employee.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  emp : Employee;

  constructor(private service : EmpserviceService, 
    private route : Router) {
    this.emp = new Employee();
  }

  ngOnInit() {
  }

  saveEmp() { // call on submit of add form
    // delegating call to service
    this.service.addEmp(this.emp);
    this.emp = new Employee();
    this.route.navigate(['list']);
  }
}
