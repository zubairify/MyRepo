import { Component, OnInit } from '@angular/core';
import { EmpserviceService } from '../services/empservice.service';
import { Employee } from '../models/employee.model';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  emps : Employee[];

  constructor(private service : EmpserviceService) { 
    setTimeout(()=>{this.emps = this.service.fetchAll()}, 100);
  }

  ngOnInit() {
  }

  remove(index: number) {
    var ans = confirm("Are You Sure You want To delete employee?")
    if (ans) {
      this.service.deleteEmp(index); //delete from service
    }
  }

  edit(index: number) {
    this.service.editEmp(index); //edit in service
  }

  sortBySalary() {
    this.service.sortEmpBySalary();
  }

  sortByName() {
    this.service.sortEmpByName();
  }
}
